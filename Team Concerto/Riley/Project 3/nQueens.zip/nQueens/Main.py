import random

# Creates default set of obstacles using example given in class
obstacles = set()
obstacles.add((0, 0))
obstacles.add((3, 2))
obstacles.add((4, 2))


# Generates a random coordinate for a queen to be placed
def generateRandChrom():
    randQueenCoord = set()

    while len(randQueenCoord) < nQueens:
        x, y = 0, 0
        while (x, y) in obstacles:
            x, y = random.randint(0, 7), random.randint(0, 7)
        randQueenCoord.add((x, y))

    return randQueenCoord


# Generates queen placements that are not random
def generateQueen(pop, maxFitness):
    mutationProb = 0.12
    nextStartingPop = []
    probs = [probability(n, maxFitness) for n in pop]

    for i in range(len(pop)):
        c1 = generateRand(pop, probs)
        c2 = generateRand(pop, probs)
        c1c2child = crossover(c1, c2)
        if random.random() <= mutationProb:
            c1c2child = mutate(c1c2child)

        nextStartingPop.append(c1c2child)

        if maxFitness(c1c2child) == maxFitness:
            break

    return nextStartingPop


# If the mutation took place the probability is checked here
def generateRand(pop, prob):
    popProb = zip(pop, prob)
    probTot = sum(prob for pop, prob in popProb)
    rnd = random.uniform(0, probTot)
    total = 0

    for pop, prob in zip(pop, prob):
        if total + prob >= rnd:
            return pop
        total += prob
    assert False, "Error"


def probability(currC, fitness):
    return fitness(currC) / maxFitness


def crossover(c1, c2):
    c = random.randint(0, (len(c1)) - 1)
    return list(c1)[0:c] + list(c2)[c:(len(c1))]


# Mutates two chromosomes together
def mutate(c1c2child):
    mutation1 = 0
    mutation2 = 0
    while (mutation1, mutation2) in obstacles:
        c = random.randint(0, nQueens - 1)
        mutation1 = random.randint(0, 7)
        mutation2 = random.randint(0, 7)
    c1c2child[c] = (mutation1, mutation2)
    return c1c2child


# Fitness function that actually determines the overall score of the board and queen layout
def fitnessFunction(chromosome):
    score = 0
    intrcpt = 0
    baseSet = set()
    for qCords in chromosome:
        score += 1
        hSet = set()
        vSet = set()
        dSet1 = set()
        dSet2 = set()

        if qCords not in baseSet:
            baseSet.add(qCords)

        # Left
        for i in range(qCords[1] - 1, -1, -1):
            currCoords = (qCords[0], i)
            if currCoords in obstacles:
                break
            else:
                hSet.add(currCoords)

        # Right
        for i in range(qCords[1] + 1, 8):
            currCoords = (qCords[0], i)
            if currCoords in obstacles:
                break
            else:
                hSet.add(currCoords)

        # Up
        for i in range(qCords[0] - 1, -1, -1):
            currCoords = (i, qCords[1])
            if currCoords in obstacles:
                break
            else:
                vSet.add(currCoords)

        # Down
        for i in range(qCords[0] + 1, 8):
            currCoords = (i, qCords[1])
            if currCoords in obstacles:
                break
            else:
                vSet.add(currCoords)

        # Diagonal Down Left
        for x, y in zip(range(qCords[0] + 1, 8, 1), range(qCords[1] + 1, 8, 1)):
            if (x, y) in obstacles:
                break
            else:
                dSet1.add((x, y))

        # Diagonal Up Right
        for x, y in zip(range(qCords[0] - 1, -1, -1), range(qCords[1] - 1, -1, -1)):
            if (x, y) in obstacles:
                break
            else:
                dSet1.add((x, y))

        # Diagonal Up Left
        for x, y in zip(range(qCords[0] - 1, -1, -1), range(qCords[1] + 1, 8, 1)):
            if (x, y) in obstacles:
                break
            else:
                dSet2.add((x, y))

        # Diagonal Down right
        for x, y in zip(range(qCords[0] + 1, 8, 1), range(qCords[1] - 1, -1, -1)):
            if (x, y) in obstacles:
                break
            else:
                dSet2.add((x, y))

        for queenCoords in chromosome:
            if qCords != queenCoords:
                if queenCoords in hSet:
                    intrcpt += 1
                if queenCoords in vSet:
                    intrcpt += 1
                if queenCoords in dSet1:
                    intrcpt += 1
                if queenCoords in dSet2:
                    intrcpt += 1

    baseSetSize = len(baseSet)

    return int((baseSetSize * (baseSetSize - 1) / 2) - intrcpt)


nQueens = 9
maxFitness = 36
pop = [generateRandChrom() for _ in range(120)]
generation = 1

print("Solution looking for max fitness of: " + str(maxFitness))

while not maxFitness in [fitnessFunction(chrom) for chrom in pop]:
    pop = generateQueen(pop, fitnessFunction)
    if (generation % 100 == 0):
        print("Current generation: " + str(generation))
        print("")

    if(generation % 300 == 0):
        pop = [generateRandChrom() for _ in range(120)]
        print("Population was reset")
        print("")

    generation += 1

print("The solution was found in generation " + str(generation - 1))

for currC in pop:
    if fitnessFunction(currC) == maxFitness:
        print("")
        print("Solution found: ")
        qCoords = currC
        print("Queen coordinates = {}".format(str(currC)))

blankBoard = []

for x in range(8):
    blankBoard.append(["X"] * 8)

for x,y in qCoords:
    blankBoard[x][y] = "Q"

for x,y in obstacles:
    blankBoard[x][y] = "O"

for r in blankBoard:
    for c in r:
        if c == 'X':
            print('| X ', end='')
        elif c == 'O':
            print('| O ', end='')
        elif 'Q' in c:
            print('| Q ', end='')
    print('|')
