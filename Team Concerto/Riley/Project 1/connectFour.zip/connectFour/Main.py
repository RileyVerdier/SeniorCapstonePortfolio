"""
Created By: Riley Verdier March 2nd, 2021
"""
import copy as copy


# Function takes 2d array that represents board and int that represents player number. Determines score ranging from
# -3 to 3 where negatives represent number of enemy in a row and a positive would indicate how many of your own
# takes priority for positive/aggressive moves as long as score is not -3
def eval(currBoard, player):
    priorityScoreHigh = 0
    priorityScoreLow = 0
    score = 0

    if player == 1:
        enemy = 2
    if player == 2:
        enemy = 1

    for i in range(6):
        for j in range(7):
            if currBoard[i][j] == 1 and player == 1:
                score = directions(currBoard, i, j)
                if score > priorityScoreHigh: priorityScoreHigh = score
            elif currBoard[i][j] == 2 and player == 1:
                score = directions(currBoard, i, j)
                score = score - (2 * score)
                if score < priorityScoreLow: priorityScoreLow = score
            if currBoard[i][j] == 1 and player == 2:
                score = directions(currBoard, i, j)
                score = score - (2 * score)
                if score < priorityScoreLow: priorityScoreLow = score
            elif currBoard[i][j] == 2 and player == 2:
                score = directions(currBoard, i, j)
                if score > priorityScoreHigh: priorityScoreHigh = score

    if (priorityScoreHigh + priorityScoreLow) >= 0:
        return priorityScoreHigh

    if (priorityScoreHigh + priorityScoreLow) < 0:
        return priorityScoreLow

    return 0


# Helper function that checks all directions of given coordinate/slot on board
def directions(checkBoard, col, row):
    streak = 1
    curNum = checkBoard[col][row]

    # check right
    if row + 1 <= 6 and checkBoard[col][row + 1] == curNum:
        streak += 1
        if row + 2 <= 6 and checkBoard[col][row + 2] == curNum:
            streak += 1

    # check left
    if row - 1 >= 0 and checkBoard[col][row - 1] == curNum :
        streak += 1
        if row - 2 >= 0 and checkBoard[col][row - 2] == curNum:
            streak += 1

    # check up
    if col - 1 >= 0 and checkBoard[col - 1][row] == curNum:
        streak += 1
        if col - 2 >= 0 and checkBoard[col - 2][row] == curNum:
            streak += 1

    # check down
    if col + 1 <= 5 and checkBoard[col + 1][row] == curNum:
        streak += 1
        if col + 2 <= 5 and checkBoard[col + 2][row] == curNum:
            streak += 1

    # check up right diagonal
    if col - 1 >= 0 and row + 1 <= 6 and checkBoard[col - 1][row + 1] == curNum :
        streak += 1
        if col - 2 >= 0 and row + 2 <= 6 and checkBoard[col - 2][row + 2] == curNum:
            streak += 1

    # check up left diagonal
    if col - 1 >= 0 and row - 1 >= 0 and checkBoard[col - 1][row - 1] == curNum :
        streak += 1
        if col - 2 >= 0 and row - 2 >= 0 and checkBoard[col - 2][row - 2] == curNum:
            streak += 1

    # check down right diagonal
    if col + 1 <= 5 and row + 1 <= 6 and checkBoard[col + 1][row + 1] == curNum:
        streak += 1
        if col + 2 <= 5 and row + 2 <= 6 and checkBoard[col + 2][row + 2] == curNum:
            streak += 1

    # check down left diagonal
    if col + 1 <= 5 and row - 1 >= 0 and checkBoard[col + 1][row - 1] == curNum:
        streak += 1
        if col + 2 <= 5 and row - 2 >= 0 and checkBoard[col + 2][row - 2] == curNum:
            streak += 1

    return streak


# Returns the next valid move after basic validation checks
def minimax(board, depth, alpha, beta, maxScore, player, enemy):
    if depth == 4 or not checkMove(board):
        return None, eval(board, player)
    return minimaxHelper(board, depth, alpha, beta, maxScore, player, enemy)


# Helper Function for minimax, checks the respective scores to decide best move given current board state
def minimaxHelper(board, depth, alpha, beta, maxScore, player, enemy):
    checkValid = checkMove(board)
    placement = checkValid[0]

    if maxScore:
        maxEval = float('-inf')
        for move in checkValid:
            board_copy = copy.deepcopy(board)
            board_copy[move[0]][move[1]] = player

            current_eval = minimax(board_copy, depth + 1, alpha, beta, False, player, enemy)[1]

            if current_eval > maxEval:
                maxEval = current_eval
                placement = move

            alpha = max(alpha, current_eval)

            if beta <= alpha:
                break

        return placement, maxEval
    else:
        worst = float('inf')
        for move in checkValid:
            board_copy = copy.deepcopy(board)
            board_copy[move[0]][move[1]] = enemy

            current_eval = minimax(board_copy, depth + 1, alpha, beta, False, player, enemy)[1]

            if current_eval < worst:
                worst = current_eval
                placement = move

            beta = min(beta, current_eval)

            if beta <= alpha:
                break

        return placement, worst


# Checks if move is valid (does not run off row or column)
def checkMove(board):
    checkValid = []

    for c in range(6):
        r = 0
        while r < 5 and board[r][c] == 0:
            r += 1

        r -= 1

        if r >= 0 and board[r][c] == 0:
            currCoordinate = []
            currCoordinate.append(r)
            currCoordinate.append(c)
            checkValid.append(currCoordinate)

    return checkValid


# Function returns next move after being selected from minimax
def move(board, player):
    if player == 1:
        enemy = 2
    if player == 2:
        enemy = 1
    (move, score) = minimax(board, 0, float('-inf'), float('inf'), True, player, enemy)

    return move[1]
