/*
    Joshua Freeman
    Regular expression simplifier
    10/17/19
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

public class parser {

    public static ArrayList<String> nineOne(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();
        int indexFirstPlus = 0;
        int indexLeftParen = 0;
        int indexSecondPlus = 0;
        int indexRightParen = 0;
        HashMap<Integer, Integer> indexPlus = new HashMap<Integer, Integer>();
        int openParen = 0;
        int closedParen = 0;
        int parenDifference = 0;

        //Find every "+" in the input with the difference of open and closed parentheses
        for (int i = 0; i < input.size(); i++) {

            if (input.get(i).equals("(")) {
                openParen++;
            }
            if (input.get(i).equals(")")) {
                closedParen++;
            }
            parenDifference = openParen - closedParen;
            if (input.get(i).equals("+")) {
                indexPlus.put(i, parenDifference);
            }
        }

        int totalI1 = 0;
        int totalI2 = 0;
        int count;

        //Find correct pair of "+" with associated "(" and ")"
        for (Integer index : indexPlus.keySet()) {
            //Find pair of "+"s where the second "+" is inside only one more "("
            if (indexSecondPlus == 0)
                indexFirstPlus = index;
            totalI2 = 0;
            for (Integer index2 : indexPlus.keySet()) {
                if (indexPlus.get(index2) == indexPlus.get(indexFirstPlus) + 1 && totalI1 < totalI2 && indexSecondPlus == 0)
                    indexSecondPlus = index2;
                totalI2++;
            }
            totalI1++;

            if (indexSecondPlus != 0) {
                openParen = 0;
                closedParen = 0;
                count = indexSecondPlus;
                //Find left parentheses "("
                while (count >= 0) {

                    if (input.get(count).equals(")")) {
                        closedParen++;
                    } else if (input.get(count).equals("(")) {
                        openParen++;
                    }
                    if (openParen == closedParen + 1) {
                        indexLeftParen = count;
                        count = -1;
                    }
                    count--;
                }

                openParen = 0;
                closedParen = 0;
                count = indexSecondPlus;
                //Find right parentheses ")"
                while (count < input.size()) {

                    if (input.get(count).equals("(")) {
                        openParen++;
                    } else if (input.get(count).equals(")")) {
                        closedParen++;
                    }
                    if (closedParen == openParen + 1) {
                        indexRightParen = count;
                        count = input.size();
                    }
                    count++;
                }
            }

            //See if the parentheses match each other
            if (indexFirstPlus + 1 != indexLeftParen)
                indexSecondPlus = 0;
        }

        //If the order of symols from left to right are +, (, +, )
        if (indexFirstPlus < indexLeftParen && indexLeftParen < indexSecondPlus && indexSecondPlus < indexRightParen) {
            ArrayList<String> alpha = new ArrayList<String>();
            ArrayList<String> beta = new ArrayList<String>();
            ArrayList<String> gamma = new ArrayList<String>();

            count = indexFirstPlus - 1;
            boolean foundAlpha = false;
            int nClosedParen = 0;
            int nOpenParen = 0;

            //Find alpha
            while (!foundAlpha && count >= 0) {

                if (input.get(count).equals(")")) {
                    nClosedParen++;
                } else if (input.get(count).equals("(")) {
                    nOpenParen++;
                }

                if (nOpenParen == nClosedParen) {
                    foundAlpha = true;
                }

                alpha.add(input.get(count));

                count--;
            }
            int alphaStart = count + 1;
            alpha = reverse(alpha);

            //Find beta
            for (int j = indexLeftParen + 1; j < indexSecondPlus; j++) {
                beta.add(input.get(j));
            }
            //Find gamma
            for (int j = indexSecondPlus + 1; j < indexRightParen; j++) {
                gamma.add(input.get(j));
            }

            //Rearrange alpha beta and gamma for outputOne
            for (int j = 0; j < alphaStart; j++) {
                ret.add(input.get(j));
            }
            ret.add("(");
            for (int j = 0; j < alpha.size(); j++) {
                ret.add(alpha.get(j));
            }
            ret.add("+");
            for (int j = 0; j < beta.size(); j++) {
                ret.add(beta.get(j));
            }

            ret.add(")");
            ret.add("+");
            for (int j = 0; j < gamma.size(); j++) {
                ret.add(gamma.get(j));
            }
            for (int j = indexRightParen + 1; j < input.size(); j++) {
                ret.add(input.get(j));
            }
        } else {
            return input;
        }

        return ret;
    }

    public static ArrayList<String> nineTwo(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();
        ArrayList<Integer> plusIndex = new ArrayList<Integer>();

        //Find every "+" in the input
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i).equals("+")) {
                plusIndex.add(i);
            }
        }
        if (!plusIndex.isEmpty()) {
            for (int i = 0; i < plusIndex.size(); i++) {
                //If mulitple "+"s were found and at least second iteration, set the new statement to the old statement
                if (i > 0) {
                    input = ret;
                    ret = new ArrayList<String>();
                }

                ArrayList<String> alpha = new ArrayList<String>();
                ArrayList<String> beta = new ArrayList<String>();
                int nOpenParen = 0;
                int nClosedParen = 0;
                boolean foundPattern = false;
                int count = plusIndex.get(i) - 1;

                //Find alpha
                while (!foundPattern && count >= 0) {

                    if (input.get(count).equals(")")) {
                        nClosedParen++;
                    } else if (input.get(count).equals("(")) {
                        nOpenParen++;
                    }

                    if (nOpenParen == nClosedParen) {
                        foundPattern = true;
                    }

                    alpha.add(input.get(count));

                    count--;
                }
                alpha = reverse(alpha);
                int alphaStart = count + 1;

                nOpenParen = 0;
                nClosedParen = 0;
                foundPattern = false;
                count = plusIndex.get(i) + 1;
                //Find beta
                while (!foundPattern && count < input.size()) {

                    if (input.get(count).equals("(")) {
                        nOpenParen++;
                    } else if (input.get(count).equals(")")) {
                        nClosedParen++;
                    }

                    if (nOpenParen == nClosedParen) {
                        foundPattern = true;
                    }

                    beta.add(input.get(count));

                    count++;
                }
                int betaStart = count - 1;
                int indexPlus = plusIndex.get(i);

                //Rearrange alpha beta and gamma for outputOne
                if ((alphaStart - 1 == -1 || input.get(alphaStart - 1).equals("(") || input.get(alphaStart - 1).equals("+")) && ((betaStart + 1 == input.size() || input.get(betaStart + 1).equals(")") || input.get(betaStart + 1).equals("+")))) {
                    for (int j = 0; j < alphaStart; j++) {
                        ret.add(input.get(j));
                    }
                    for (int j = 0; j < beta.size(); j++) {
                        ret.add(beta.get(j));
                    }
                    ret.add("+");
                    for (int j = 0; j < alpha.size(); j++) {
                        ret.add(alpha.get(j));
                    }
                    for (int j = betaStart + 1; j < input.size(); j++) {
                        ret.add(input.get(j));
                    }
                } else
                    return input;

            }
        } else {
            return input;
        }

        return ret;
    }

    public static ArrayList<String> nineThree(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();

        //int indexPlus = 0;
        int indexMTST = 0;

        boolean foundMTST = false;
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i).equals("MTST")) {
                indexMTST = i;
                foundMTST = true;
            }
        }
        //If MTST was found to the right of alpha and a "+" symbol is the next left token
        if ((foundMTST && indexMTST - 1 > 0 && input.get(indexMTST - 1).equals("+")) && (indexMTST == input.size() - 1 || input.get(indexMTST + 1).equals(")") || input.get(indexMTST + 1).equals("+"))) {

            for (int j = 0; j < indexMTST - 1; j++) {
                ret.add(input.get(j));
            }
            for (int j = indexMTST + 1; j < input.size(); j++) {
                ret.add(input.get(j));
            }

            //If MTST was found to the left of a alpha and a "+" symbol is the next right token
        } else if ((foundMTST && indexMTST + 1 < input.size() - 1 && input.get(indexMTST + 1).equals("+")) && (indexMTST == 0 || input.get(indexMTST - 1).equals("(") || input.get(indexMTST - 1).equals("+"))) {

            for (int j = 0; j < indexMTST; j++) {
                ret.add(input.get(j));
            }
            for (int j = indexMTST + 2; j < input.size(); j++) {
                ret.add(input.get(j));
            }
        } else {
            return input;
        }

        return ret;
    }

    public static ArrayList<String> nineFour(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();
        ArrayList<Integer> plusIndex = new ArrayList<Integer>();

        //Find every plus in input
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i).equals("+")) {
                plusIndex.add(i);
            }
        }
        if (plusIndex.isEmpty() == false)
            for (int i = 0; i < plusIndex.size(); i++) {
                int indexPlus = plusIndex.get(i);
                ArrayList<String> alpha1 = new ArrayList<String>();
                ArrayList<String> alpha2 = new ArrayList<String>();

                int nOpenParen = 0;
                int nClosedParen = 0;
                boolean foundAlpha = false;
                int count = indexPlus - 1;
                //Find alpha to left of "+" symbol
                while (!foundAlpha && count >= 0) {

                    if (input.get(count).equals(")")) {
                        nClosedParen++;
                    } else if (input.get(count).equals("(")) {
                        nOpenParen++;
                    }

                    if (nOpenParen == nClosedParen) {
                        foundAlpha = true;
                    }

                    alpha1.add(input.get(count));

                    count--;
                }
                alpha1 = reverse(alpha1);

                nOpenParen = 0;
                nClosedParen = 0;
                foundAlpha = false;
                count = indexPlus + 1;
                //Find alpha to the right of "+" symbol
                while (!foundAlpha && count < input.size()) {

                    if (input.get(count).equals("(")) {
                        nOpenParen++;
                    } else if (input.get(count).equals(")")) {
                        nClosedParen++;
                    }

                    if (nOpenParen == nClosedParen) {
                        foundAlpha = true;
                    }

                    alpha2.add(input.get(count));

                    count++;
                }
                int alpha2Start = count - 1;

                //Compare to see if both alphas are the same
                boolean sameTokens = compareTokens(alpha1, alpha2);

                //Rearrange input
                if (sameTokens) {
                    for (int j = 0; j < indexPlus; j++) {
                        ret.add(input.get(j));
                    }
                    for (int j = alpha2Start + 1; j < input.size(); j++) {
                        ret.add(input.get(j));
                    }
                }
            }
        else
            return input;

        if (ret.isEmpty())
            return input;
        else
            return ret;
    }

    //How does it work with multiple tokens?
    //( ALPHA + BETA + ( GAMMA + ZETA ) ) ( BETA ( GAMMA ) )
    //Check for 2 terms in ( ), token before ( - can't be + or end of bounds
    public static ArrayList<String> nineFive(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();
        int indexLeftParen = 0;
        int indexRightParen = 0;
        TreeMap<Integer, Integer> parentheses = new TreeMap<Integer, Integer>();

        //Create map where key is index of "(" and the value is the index of ")"
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i).equals("(")) {
                parentheses.put(i, 0);
            }

            if (input.get(i).equals(")")) {
                HashMap<Integer, Integer> fullMaps = new HashMap<Integer, Integer>();
                boolean notFound = true;
                while (notFound && parentheses.size() > 0) {
                    int currKey = parentheses.lastKey();

                    if (parentheses.get(currKey) == 0) {
                        parentheses.replace(currKey, i);
                        parentheses.putAll(fullMaps);
                        notFound = false;
                    } else
                        fullMaps.put(currKey, parentheses.remove(currKey));

                }
            }
        }

        if (!parentheses.isEmpty()) {
            while (!parentheses.isEmpty()) {
                if (parentheses.firstKey() != 0 && !input.get(parentheses.firstKey() - 1).equals("+")) {
                    ArrayList<String> alpha = new ArrayList<String>();
                    ArrayList<String> beta = new ArrayList<String>();
                    ArrayList<String> gamma = new ArrayList<String>();
                    indexLeftParen = parentheses.firstKey();
                    indexRightParen = parentheses.remove(indexLeftParen);


                    //Find alpha
                    int nOpenParen = 0;
                    int nClosedParen = 0;
                    boolean foundAlpha = false;
                    int count = indexLeftParen - 1;
                    while (!foundAlpha && count >= 0) {

                        if (input.get(count).equals(")")) {
                            nClosedParen++;
                        } else if (input.get(count).equals("(")) {
                            nOpenParen++;
                        }

                        if (nOpenParen == nClosedParen) {
                            foundAlpha = true;
                        }

                        alpha.add(input.get(count));

                        count--;
                    }
                    int alphaStart = count + 1;
                    alpha = reverse(alpha);
                    nOpenParen = 0;
                    nClosedParen = 0;
                    boolean foundPattern = false;
                    count = indexLeftParen + 1;
                    //Find beta
                    while (!foundPattern && count < input.size()) {

                        if (input.get(count).equals("(")) {
                            nOpenParen++;
                        } else if (input.get(count).equals(")")) {
                            nClosedParen++;
                        }

                        if (nOpenParen == nClosedParen) {
                            foundPattern = true;
                        }

                        beta.add(input.get(count));

                        count++;
                    }
                    int gammaEnd;
                    if (count < input.size() && !input.get(count).equals("+")) {
                        nOpenParen = 0;
                        nClosedParen = 0;
                        foundPattern = false;
                        //Find gamma
                        while (!foundPattern && count < input.size()) {

                            if (input.get(count).equals("(")) {
                                nOpenParen++;
                            } else if (input.get(count).equals(")")) {
                                nClosedParen++;
                            }

                            if (nOpenParen == nClosedParen) {
                                foundPattern = true;
                            }

                            gamma.add(input.get(count));

                            count++;
                        }
                        gammaEnd = count - 1;
                    } else
                        return input;

                    //Rearrange input
                    for (int j = 0; j < alphaStart; j++) {
                        ret.add(input.get(j));
                    }
                    ret.add("(");
                    for (String s : alpha) {
                        ret.add(s);
                    }
                    for (String s : beta) {
                        ret.add(s);
                    }
                    ret.add(")");
                    for (String s : gamma) {
                        ret.add(s);
                    }
                    for (int j = gammaEnd + 2; j < input.size(); j++) {
                        ret.add(input.get(j));
                    }
                    return ret;
                }
                parentheses.remove(parentheses.firstKey());
            }

        } else
            return input;
        return ret;
    }

    public static ArrayList<String> nineSix(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();
        int indexEpsilon = 0;
        boolean isFound = false;
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i).equals("EPSILON")) {
                indexEpsilon = i;
                isFound = true;
            }

        }

        if (isFound) {
            //If at final token and previous token wasnt plus
            //Not at final token and next token is plus
            //Right token for rule
            if ((input.size() >= 2 && indexEpsilon != 0 && !input.get(indexEpsilon - 1).equals("+") && !input.get(indexEpsilon - 1).equals(")") && !input.get(indexEpsilon - 1).equals("*"))) {
                for (int i = 0; i < indexEpsilon; i++) {
                    ret.add(input.get(i));
                }
                for (int i = indexEpsilon + 1; i < input.size(); i++) {
                    ret.add(input.get(i));
                }
                //if beginning and no plus
                // Not at beginning and previous token wasn't plus
                //Left token for rule
            } else if ((indexEpsilon != input.size() - 1 && !input.get(indexEpsilon + 1).equals("+") && !input.get(indexEpsilon + 1).equals("("))) {
                for (int i = 0; i < indexEpsilon; i++) {
                    ret.add(input.get(i));
                }
                for (int i = indexEpsilon + 1; i < input.size(); i++) {
                    ret.add(input.get(i));
                }
            } else
                return input;
        } else
            return input;
        return ret;
    }

    public static ArrayList<String> nineSeven(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();
        int indexLeftParen = 0;
        ArrayList<Integer> plusIndexSameParen = new ArrayList<Integer>();
        int openParen = 0;
        int closedParen = 0;
        int parenDifference = 0;

        //Find "+" inside parentheses
        for (int i = 0; i < input.size(); i++) {

            if (input.get(i).equals("(")) {
                openParen++;
            }
            if (input.get(i).equals(")")) {
                closedParen++;
            }
            parenDifference = openParen - closedParen;
            if (input.get(i).equals("+") && parenDifference == 1) {
                plusIndexSameParen.add(i);
            }
        }


        for (Integer index : plusIndexSameParen) {

            ArrayList<String> alpha = new ArrayList<String>();
            ArrayList<String> beta = new ArrayList<String>();
            ArrayList<String> gamma = new ArrayList<String>();
            int nOpenParen = 0;
            int nClosedParen = 0;
            boolean foundPattern = false;
            int count = index - 1;
            //Find beta to left of "+"
            while (!foundPattern && count >= 0) {

                if (input.get(count).equals(")")) {
                    nClosedParen++;
                } else if (input.get(count).equals("(")) {
                    nOpenParen++;
                }

                if (nOpenParen == nClosedParen) {
                    foundPattern = true;
                }

                beta.add(input.get(count));

                count--;
            }

            beta = reverse(beta);

            indexLeftParen = count;
            //Determine if the token to the left of beta is being "multiplied" and not "added"
            if (indexLeftParen - 1 >= 0 && !input.get(indexLeftParen - 1).equals("+")) {
                nOpenParen = 0;
                nClosedParen = 0;
                foundPattern = false;

                count--;
                //Find alpha to left of beta
                while (!foundPattern && count >= 0) {

                    if (input.get(count).equals(")")) {
                        nClosedParen++;
                    } else if (input.get(count).equals("(")) {
                        nOpenParen++;
                    }

                    if (nOpenParen == nClosedParen) {
                        foundPattern = true;
                    }

                    alpha.add(input.get(count));

                    count--;
                }
                alpha = reverse(alpha);
                int alphaStart = count + 1;

                count = index + 1;
                nOpenParen = 0;
                nClosedParen = 0;
                foundPattern = false;
                //Find gamma to right of "+"
                while (!foundPattern && count < input.size()) {

                    if (input.get(count).equals("(")) {
                        nOpenParen++;
                    } else if (input.get(count).equals(")")) {
                        nClosedParen++;
                    }

                    if (nOpenParen == nClosedParen) {
                        foundPattern = true;
                    }

                    gamma.add(input.get(count));

                    count++;
                }
                int gammaEnd = count - 1;

                //Rearrange alpha beta and gamma for outputOne

                for (int j = 0; j < alphaStart; j++) {
                    ret.add(input.get(j));
                }
                for (int j = 0; j < alpha.size(); j++) {
                    ret.add(alpha.get(j));
                }
                for (int j = 0; j < beta.size(); j++) {
                    ret.add(beta.get(j));
                }
                ret.add("+");
                for (int j = 0; j < alpha.size(); j++) {
                    ret.add(alpha.get(j));
                }
                for (int j = 0; j < gamma.size(); j++) {
                    ret.add(gamma.get(j));
                }
                for (int j = gammaEnd + 2; j < input.size(); j++) {
                    ret.add(input.get(j));
                }
                return ret;
            }
        }
        return input;

    }

    public static ArrayList<String> nineEight(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();
        int indexRightParen = 0;
        ArrayList<Integer> plusIndexSameParen = new ArrayList<Integer>();
        int openParen = 0;
        int closedParen = 0;
        int parenDifference = 0;

        //Find list of "+" where the symbol is inside parentheses
        for (int i = 0; i < input.size(); i++) {

            if (input.get(i).equals("(")) {
                openParen++;
            }
            if (input.get(i).equals(")")) {
                closedParen++;
            }
            parenDifference = openParen - closedParen;
            if (input.get(i).equals("+") && parenDifference == 1) {
                plusIndexSameParen.add(i);
            }
        }

        for (Integer index : plusIndexSameParen) {
            ArrayList<String> alpha = new ArrayList<String>();
            ArrayList<String> beta = new ArrayList<String>();
            ArrayList<String> gamma = new ArrayList<String>();

            int count = index + 1;
            int nOpenParen = 0;
            int nClosedParen = 0;
            boolean foundPattern = false;
            //Find beta
            while (!foundPattern && count < input.size()) {

                if (input.get(count).equals("(")) {
                    nOpenParen++;
                } else if (input.get(count).equals(")")) {
                    nClosedParen++;
                }

                if (nOpenParen == nClosedParen) {
                    foundPattern = true;
                }

                beta.add(input.get(count));

                count++;
            }


            indexRightParen = count;

            //Check if next token to right of beta is not being "added"
            if (indexRightParen + 1 < input.size() && !input.get(indexRightParen + 1).equals("+")) {

                count = indexRightParen + 1;
                nOpenParen = 0;
                nClosedParen = 0;
                foundPattern = false;
                //Find gamma
                while (!foundPattern && count < input.size()) {

                    if (input.get(count).equals("(")) {
                        nOpenParen++;
                    } else if (input.get(count).equals(")")) {
                        nClosedParen++;
                    }

                    if (nOpenParen == nClosedParen) {
                        foundPattern = true;
                    }

                    gamma.add(input.get(count));

                    count++;
                }
                int gammaEnd = count - 1;

                nOpenParen = 0;
                nClosedParen = 0;
                foundPattern = false;
                count = index - 1;

                //Find alpha
                while (!foundPattern && count >= 0) {

                    if (input.get(count).equals(")")) {
                        nClosedParen++;
                    } else if (input.get(count).equals("(")) {
                        nOpenParen++;
                    }

                    if (nOpenParen == nClosedParen) {
                        foundPattern = true;
                    }

                    alpha.add(input.get(count));

                    count--;
                }
                alpha = reverse(alpha);
                int alphaStart = count + 1;


                //Rearrange alpha beta and gamma for outputOne

                for (int j = 0; j < alphaStart - 1; j++) {
                    ret.add(input.get(j));
                }
                for (int j = 0; j < alpha.size(); j++) {
                    ret.add(alpha.get(j));
                }
                for (int j = 0; j < gamma.size(); j++) {
                    ret.add(gamma.get(j));
                }
                ret.add("+");
                for (int j = 0; j < beta.size(); j++) {
                    ret.add(beta.get(j));
                }
                for (int j = 0; j < gamma.size(); j++) {
                    ret.add(gamma.get(j));
                }
                for (int j = gammaEnd + 1; j < input.size(); j++) {
                    ret.add(input.get(j));
                }
                return ret;
            }
        }
        return input;

    }

    public static ArrayList<String> nineNine(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();
        int indexMTST = 0;
        boolean isFound = false;
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i).equals("MTST")) {
                indexMTST = i;
                isFound = true;
            }

        }

        if (isFound) {
            //If at final token and previous token wasnt plus
            //Not at final token and next token is plus
            //Right token for rule
            if ((input.size() >= 2 && indexMTST != 0 && !input.get(indexMTST - 1).equals("+") && !input.get(indexMTST - 1).equals(")") && !input.get(indexMTST - 1).equals("*")) /*|| (indexMTST != input.size()-1 && !input.get(indexMTST + 1).equals("+")&& !input.get(indexMTST + 1).equals("("))*/) {
                for (int i = 0; i < indexMTST - 1; i++) {
                    ret.add(input.get(i));
                }
                for (int i = indexMTST; i < input.size(); i++) {
                    ret.add(input.get(i));
                }
                //if beginning and no plus
                // Not at beginning and previous token wasn't plus
                //Left token for rule
            } else if ((indexMTST != input.size() - 1 && !input.get(indexMTST + 1).equals("+") && !input.get(indexMTST + 1).equals("(")) /*|| (indexMTST != 0 && !input.get(indexMTST - 1).equals("+")&& !input.get(indexMTST - 1).equals(")")&& !input.get(indexMTST - 1).equals("*"))*/) {
                for (int i = 0; i <= indexMTST; i++) {
                    ret.add(input.get(i));
                }
                for (int i = indexMTST + 2; i < input.size(); i++) {
                    ret.add(input.get(i));
                }
            } else
                return input;
        } else
            return input;
        return ret;
    }

    private static ArrayList<String> nineTen(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();
        ArrayList<Integer> epsilonIndexes = new ArrayList<Integer>();

        int indexEpsilon = 0;
        int indexPlus = 0;
        //Find every occurrence of EPSILON
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i).equals("EPSILON")) {
                epsilonIndexes.add(i);
            }
        }

        for (Integer index : epsilonIndexes) {
            indexEpsilon = index;
            //if((indexEpsilon == 0 || (indexEpsilon == 1 && input.get(indexEpsilon -1).equals("("))) || (indexEpsilon == input.size() -1 || (indexEpsilon == input.size() -2  && input.get(indexEpsilon + 1).equals(")"))))
            //Check to make sure required tokens are in input
            if ((indexEpsilon + 2 < input.size() - 1 && (input.get(indexEpsilon + 1).equals("+") || (input.get(indexEpsilon + 1).equals(")") && input.get(indexEpsilon + 2).equals("+")))) || (indexEpsilon - 2 > 0 && (input.get(indexEpsilon - 1).equals("+") || (input.get(indexEpsilon - 1).equals("())") && input.get(indexEpsilon - 2).equals("+"))))) {
                ArrayList<String> alpha1 = new ArrayList<String>();
                ArrayList<String> alpha2 = new ArrayList<String>();
                int indexAlpha1 = 0;
                int indexEndAlpha2 = 0;
                boolean left = false;
                int count;
                boolean sameAlpha;
                //If EPSILON is on left of alphas and not in parentheses
                if (indexEpsilon + 2 < input.size() - 1 && (input.get(indexEpsilon + 1).equals("+") && (indexEpsilon - 2 >= 0 && !input.get(indexEpsilon - 2).equals("*")))) {
                    indexPlus = indexEpsilon + 1;
                    count = indexPlus + 1;
                    left = true;
                //If EPSILON is on left of alphas and in parentheses
                } else if (indexEpsilon + 2 < input.size() - 1 && (input.get(indexEpsilon + 1).equals(")") && input.get(indexEpsilon + 2).equals("+") && (indexEpsilon - 2 >= 0 && !input.get(indexEpsilon - 3).equals("*")))) {
                    indexPlus = indexEpsilon + 2;
                    count = indexPlus + 1;
                    indexEpsilon--;
                    left = true;
                //If EPSILON is on right of alphas with parentheses
                } else if (indexEpsilon - 2 >= 0 && input.get(indexEpsilon - 1).equals("(")) {
                    indexPlus = indexEpsilon - 2;
                    indexEpsilon++;
                    if (!input.get(indexPlus - 1).equals("*"))
                        return input;
                    else
                        count = indexPlus - 2;
                //If EPSILON is on right of alphas without parentheses
                } else {
                    indexPlus = indexEpsilon - 1;
                    if (!input.get(indexPlus - 1).equals("*"))
                        return input;
                    else
                        count = indexPlus - 2;
                }

                int nOpenParen;
                int nClosedParen;
                boolean foundPattern;

                //If EPSILON was on left of alphas
                if (left) {
                    nOpenParen = 0;
                    nClosedParen = 0;
                    foundPattern = false;
                    //Find alpha
                    while (!foundPattern && count < input.size()) {

                        if (input.get(count).equals("(")) {
                            nOpenParen++;
                        } else if (input.get(count).equals(")")) {
                            nClosedParen++;
                        }

                        if (nOpenParen == nClosedParen) {
                            foundPattern = true;
                        }

                        alpha1.add(input.get(count));

                        count++;
                    }

                    nOpenParen = 0;
                    nClosedParen = 0;
                    foundPattern = false;
                    //Find second alpha
                    while (!foundPattern && count < input.size()) {

                        if (input.get(count).equals("(")) {
                            nOpenParen++;
                        } else if (input.get(count).equals(")")) {
                            nClosedParen++;
                        }

                        if (nOpenParen == nClosedParen) {
                            foundPattern = true;
                        }

                        alpha2.add(input.get(count));

                        count++;
                    }
                    indexEndAlpha2 = count - 1;
                    //See if alphas are the same
                    sameAlpha = compareTokens(alpha1, alpha2);
                    if (!input.get(count).equals("*"))
                        return input;
                //If EPSILON was on right of alphas
                } else {
                    foundPattern = false;
                    nOpenParen = 0;
                    nClosedParen = 0;
                    //Find second alpha
                    while (!foundPattern && count >= 0) {

                        if (input.get(count).equals(")")) {
                            nClosedParen++;
                        } else if (input.get(count).equals("(")) {
                            nOpenParen++;
                        }

                        if (nOpenParen == nClosedParen) {
                            foundPattern = true;
                        }

                        alpha2.add(input.get(count));

                        count--;
                    }

                    alpha2 = reverse(alpha2);
                    foundPattern = false;
                    nOpenParen = 0;
                    nClosedParen = 0;

                    //Find first alpha
                    while (!foundPattern && count >= 0) {

                        if (input.get(count).equals(")")) {
                            nClosedParen++;
                        } else if (input.get(count).equals("(")) {
                            nOpenParen++;
                        }

                        if (nOpenParen == nClosedParen) {
                            foundPattern = true;
                        }

                        alpha1.add(input.get(count));

                        count--;
                    }
                    alpha1 = reverse(alpha1);
                    indexAlpha1 = count + 1;
                    //Compare alphas
                    sameAlpha = compareTokens(alpha1, alpha2);
                }


                if (sameAlpha) {

                    //Rearrange output
                    if (left) {
                        for (int i = 0; i < indexEpsilon; i++) {
                            ret.add(input.get(i));
                        }
                        for (int i = 0; i < alpha2.size(); i++) {
                            ret.add(alpha2.get(i));
                        }
                        ret.add("*");
                        for (int i = indexEndAlpha2 + 2; i < input.size(); i++) {
                            ret.add(input.get(i));
                        }
                    } else {
                        for (int i = 0; i < indexAlpha1; i++) {
                            ret.add(input.get(i));
                        }
                        for (int i = 0; i < alpha2.size(); i++) {
                            ret.add(alpha2.get(i));
                        }
                        ret.add("*");
                        for (int i = indexEpsilon + 1; i < input.size(); i++) {
                            ret.add(input.get(i));
                        }
                    }

                    return ret;
                }
            }
        }
        return input;
    }

    private static ArrayList<String> nineEleven(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();
        ArrayList<Integer> epsilonIndexes = new ArrayList<Integer>();
        int indexEpsilon = 0;
        int indexPlus = 0;
        int indexStar = 0;
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i).equals("EPSILON")) {
                epsilonIndexes.add(i);
            }
            if (input.get(i).equals("*"))
                indexStar = i;
        }

        for (Integer index : epsilonIndexes) {
            indexEpsilon = index;
            //if((indexEpsilon == 0 || (indexEpsilon == 1 && input.get(indexEpsilon -1).equals("("))) || (indexEpsilon == input.size() -1 || (indexEpsilon == input.size() -2  && input.get(indexEpsilon + 1).equals(")"))))
            if ((indexEpsilon + 2 < input.size() - 1 && (input.get(indexEpsilon + 1).equals("+") || (input.get(indexEpsilon + 1).equals(")") && input.get(indexEpsilon + 2).equals("+")))) || (indexEpsilon - 2 > 0 && (input.get(indexEpsilon - 1).equals("+") || (input.get(indexEpsilon - 1).equals("())") && input.get(indexEpsilon - 2).equals("+"))))) {
                ArrayList<String> alpha1 = new ArrayList<String>();
                ArrayList<String> alpha2 = new ArrayList<String>();
                int indexAlpha1 = 0;
                int indexEndAlpha2 = 0;
                boolean left = false;
                int count;
                boolean sameAlpha;

                //If EPSILON is on left of alphas and not in parentheses
                if (indexEpsilon + 2 < input.size() - 1 && (input.get(indexEpsilon + 1).equals("+")) && indexStar > indexEpsilon) {
                    indexPlus = indexEpsilon + 1;
                    count = indexPlus + 1;
                    left = true;
                    //If EPSILON is on left of alphas and in parentheses
                } else if (indexEpsilon + 2 < input.size() - 1 && (input.get(indexEpsilon + 1).equals(")") && input.get(indexEpsilon + 2).equals("+")) && indexStar > indexEpsilon) {
                    indexPlus = indexEpsilon + 2;
                    indexEpsilon--;
                    count = indexPlus + 1;
                    left = true;
                    //If EPSILON is on right of alphas with parentheses
                } else if (indexEpsilon - 2 >= 0 && input.get(indexEpsilon - 1).equals("(") && indexStar < indexEpsilon) {
                    indexPlus = indexEpsilon - 2;
                    indexEpsilon++;
                    if (!input.get(indexPlus - 1).equals("*"))
                        return input;
                    else
                        count = indexPlus - 2;
                    //If EPSILON is on right of alphas without parentheses
                } else {
                    indexPlus = indexEpsilon - 1;
                    if (!input.get(indexPlus - 1).equals("*"))
                        return input;
                    else
                        count = indexPlus - 2;
                }


                int nOpenParen;
                int nClosedParen;
                boolean foundPattern;

                //If EPSILON is on the left of the statement
                if (left) {
                    nOpenParen = 0;
                    nClosedParen = 0;
                    foundPattern = false;
                    //Find alpha1
                    while (!foundPattern && count < input.size()) {

                        if (input.get(count).equals("(")) {
                            nOpenParen++;
                        } else if (input.get(count).equals(")")) {
                            nClosedParen++;
                        }

                        if (nOpenParen == nClosedParen) {
                            foundPattern = true;
                        }

                        alpha1.add(input.get(count));

                        count++;
                    }
                    if (!input.get(count).equals("*"))
                        return input;
                    count++;
                    nOpenParen = 0;
                    nClosedParen = 0;
                    foundPattern = false;
                    //Find alpha2
                    while (!foundPattern && count < input.size()) {

                        if (input.get(count).equals("(")) {
                            nOpenParen++;
                        } else if (input.get(count).equals(")")) {
                            nClosedParen++;
                        }

                        if (nOpenParen == nClosedParen) {
                            foundPattern = true;
                        }

                        alpha2.add(input.get(count));

                        count++;
                    }
                    indexEndAlpha2 = count - 1;
                    sameAlpha = compareTokens(alpha1, alpha2);
                //EPSILON is on the right of the statement
                } else {
                    foundPattern = false;
                    nOpenParen = 0;
                    nClosedParen = 0;
                    //Find alpha2
                    while (!foundPattern && count >= 0) {

                        if (input.get(count).equals(")")) {
                            nClosedParen++;
                        } else if (input.get(count).equals("(")) {
                            nOpenParen++;
                        }

                        if (nOpenParen == nClosedParen) {
                            foundPattern = true;
                        }

                        alpha2.add(input.get(count));

                        count--;
                    }

                    alpha2 = reverse(alpha2);
                    if (input.get(count).equals("*"))
                        return input;
                    count--;
                    foundPattern = false;
                    nOpenParen = 0;
                    nClosedParen = 0;
                    //Find alpha1
                    while (!foundPattern && count >= 0) {

                        if (input.get(count).equals(")")) {
                            nClosedParen++;
                        } else if (input.get(count).equals("(")) {
                            nOpenParen++;
                        }

                        if (nOpenParen == nClosedParen) {
                            foundPattern = true;
                        }

                        alpha1.add(input.get(count));

                        count--;
                    }
                    alpha1 = reverse(alpha1);
                    indexAlpha1 = count + 1;
                    sameAlpha = compareTokens(alpha1, alpha2);
                }

                //Rearrange the statement
                if (sameAlpha) {

                    if (left) {
                        for (int i = 0; i < indexEpsilon; i++) {
                            ret.add(input.get(i));
                        }
                        for (int i = 0; i < alpha2.size(); i++) {
                            ret.add(alpha2.get(i));
                        }
                        ret.add("*");
                        for (int i = indexEndAlpha2 + 2; i < input.size(); i++) {
                            ret.add(input.get(i));
                        }
                    } else {
                        for (int i = 0; i < indexAlpha1; i++) {
                            ret.add(input.get(i));
                        }
                        for (int i = 0; i < alpha2.size(); i++) {
                            ret.add(alpha2.get(i));
                        }
                        ret.add("*");
                        for (int i = indexEpsilon + 1; i < input.size(); i++) {
                            ret.add(input.get(i));
                        }
                    }

                    return ret;
                }
            }
        }
        return input;
    }

    private static ArrayList<String> nineTwelve(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();

        int indexPlus = 0;
        int indexLessThan = 0;
        boolean foundPlus = false;
        boolean foundLessThan = false;

        //Find + and <_
        int openParen = 0;
        int closedParen = 0;
        int parenDifference = 0;
        //Find "<_" in the statement
        for (int i = 0; i < input.size(); i++) {

            if (input.get(i).equals("(")) {
                openParen++;
            }
            if (input.get(i).equals(")")) {
                closedParen++;
            } else if (input.get(i).equals("<_")) {
                indexLessThan = i;
                foundLessThan = true;
                parenDifference = openParen - closedParen;
            }
        }
        openParen = 0;
        closedParen = 0;
        //Find "+" in the statement
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i).equals("(")) {
                openParen++;
            }
            if (input.get(i).equals(")")) {
                closedParen++;
            }
            if (input.get(i).equals("+") && openParen - closedParen == parenDifference) {
                indexPlus = i;
                foundPlus = true;
            }
        }

        ArrayList<String> alpha = new ArrayList<String>();
        ArrayList<String> beta = new ArrayList<String>();
        ArrayList<String> gamma1 = new ArrayList<String>();
        ArrayList<String> gamma2 = new ArrayList<String>();

        if (indexPlus < indexLessThan && indexLessThan != input.size() - 1 && foundPlus && foundLessThan) {

            //Find beta
            int nOpenParen = 0;
            int nClosedParen = 0;
            int count = 0;
            boolean foundPattern = false;

            while (!foundPattern && count < indexPlus) {
                if (input.get(count).equals(")")) {
                    nClosedParen++;
                } else if (input.get(count).equals("(")) {
                    nOpenParen++;
                }

                if (nOpenParen == nClosedParen) {
                    foundPattern = true;
                }

                beta.add(input.get(count));

                count++;
            }

            //Find alpha
            nOpenParen = 0;
            nClosedParen = 0;
            count = indexPlus + 1;
            foundPattern = false;

            while (!foundPattern && count < input.size()) {

                if (input.get(count).equals("(")) {
                    nOpenParen++;
                } else if (input.get(count).equals(")")) {
                    nClosedParen++;
                }

                if (nOpenParen == nClosedParen) {
                    foundPattern = true;
                }

                alpha.add(input.get(count));

                count++;
            }

            //Find gamma1
            nOpenParen = 0;
            nClosedParen = 0;
            foundPattern = false;

            while (!foundPattern && count < indexLessThan) {

                if (input.get(count).equals("(")) {
                    nOpenParen++;
                } else if (input.get(count).equals(")")) {
                    nClosedParen++;
                }

                if (nOpenParen == nClosedParen) {
                    foundPattern = true;
                }

                gamma1.add(input.get(count));

                count++;
            }

            //Find gamma2
            nOpenParen = 0;
            nClosedParen = 0;
            foundPattern = false;

            count++;
            while (!foundPattern && count < input.size()) {

                if (input.get(count).equals("(")) {
                    nOpenParen++;
                } else if (input.get(count).equals(")")) {
                    nClosedParen++;
                }

                if (nOpenParen == nClosedParen) {
                    foundPattern = true;
                }

                gamma2.add(input.get(count));

                count++;
            }

            //Rearrange the statement
            if (compareTokens(gamma1, gamma2)) {
                for (int i = 0; i < alpha.size(); i++) {
                    ret.add(alpha.get(i));
                }
                ret.add("*");
                for (int i = 0; i < beta.size(); i++) {
                    ret.add(beta.get(i));
                }
                ret.add("<_");
                for (int i = 0; i < gamma1.size(); i++) {
                    ret.add(gamma1.get(i));
                }
            } else
                return input;
        } else
            return input;
        return ret;
    }

    private static ArrayList<String> nineThirteen(ArrayList<String> input) {
        ArrayList<String> ret = new ArrayList<String>();

        int indexPlus = 0;
        int indexLessThan = 0;
        boolean foundPlus = false;
        boolean foundLessThan = false;

        //Find + and <_
        int openParen = 0;
        int closedParen = 0;
        int parenDifference = 0;
        for (int i = 0; i < input.size(); i++) {

            if (input.get(i).equals("(")) {
                openParen++;
            }
            if (input.get(i).equals(")")) {
                closedParen++;
            } else if (input.get(i).equals("<_")) {
                indexLessThan = i;
                foundLessThan = true;
                parenDifference = openParen - closedParen;
            }
        }
        openParen = 0;
        closedParen = 0;
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i).equals("(")) {
                openParen++;
            }
            if (input.get(i).equals(")")) {
                closedParen++;
            }
            if (input.get(i).equals("+") && openParen - closedParen == parenDifference) {
                indexPlus = i;
                foundPlus = true;
            }
        }

        ArrayList<String> alpha = new ArrayList<String>();
        ArrayList<String> beta = new ArrayList<String>();
        ArrayList<String> gamma1 = new ArrayList<String>();
        ArrayList<String> gamma2 = new ArrayList<String>();

        if (indexPlus < indexLessThan && indexLessThan != input.size() - 1 && foundPlus && foundLessThan) {

            //Find beta
            int nOpenParen = 0;
            int nClosedParen = 0;
            int count = 0;
            boolean foundPattern = false;

            while (!foundPattern && count < indexPlus) {
                if (input.get(count).equals(")")) {
                    nClosedParen++;
                } else if (input.get(count).equals("(")) {
                    nOpenParen++;
                }

                if (nOpenParen == nClosedParen) {
                    foundPattern = true;
                }
                if (nOpenParen != nClosedParen || nClosedParen != 0) {
                    beta.add(input.get(count));
                }
                count++;
            }

            //Find gamma
            nOpenParen = 0;
            nClosedParen = 0;
            count = indexPlus + 1;
            foundPattern = false;

            while (!foundPattern && count < input.size()) {

                if (input.get(count).equals("(")) {
                    nOpenParen++;
                } else if (input.get(count).equals(")")) {
                    nClosedParen++;
                }

                if (nOpenParen == nClosedParen) {
                    foundPattern = true;
                }
                if (nOpenParen != nClosedParen || nOpenParen != 0) {
                    gamma1.add(input.get(count));
                }
                count++;
            }

            //Find alpha
            nOpenParen = 0;
            nClosedParen = 0;
            foundPattern = false;

            while (!foundPattern && count < indexLessThan) {

                if (input.get(count).equals("(")) {
                    nOpenParen++;
                } else if (input.get(count).equals(")")) {
                    nClosedParen++;
                }

                if (nOpenParen == nClosedParen) {
                    foundPattern = true;
                }
                if (nOpenParen != nClosedParen || nOpenParen != 0) {
                    alpha.add(input.get(count));
                }
                count++;
            }


            //Find gamma2
            nOpenParen = 0;
            nClosedParen = 0;
            foundPattern = false;

            count++;
            while (!foundPattern && count < input.size()) {

                if (input.get(count).equals("(")) {
                    nOpenParen++;
                } else if (input.get(count).equals(")")) {
                    nClosedParen++;
                }

                if (nOpenParen == nClosedParen) {
                    foundPattern = true;
                }
                if (nOpenParen != nClosedParen || nOpenParen != 0) {
                    gamma2.add(input.get(count));
                }
                count++;
            }

            //Rearrange the statement
            if (compareTokens(gamma1, gamma2)) {
                for (int i = 0; i < beta.size(); i++) {
                    ret.add(beta.get(i));
                }
                for (int i = 0; i < alpha.size(); i++) {
                    ret.add(alpha.get(i));
                }
                ret.add("*");
                ret.add("<_");
                for (int i = 0; i < gamma1.size(); i++) {
                    ret.add(gamma1.get(i));
                }
            } else
                return input;
        } else
            return input;
        return ret;
    }

    //Compares two sets of tokens
    private static boolean compareTokens(ArrayList<String> t1, ArrayList<String> t2) {
        if (t1.size() != t2.size())
            return false;
        else {
            for (int i = 0; i < t1.size(); i++) {
                if (!t1.get(i).equals(t2.get(i)))
                    return false;
            }
        }

        return true;
    }

    //Reverses the array list of tokens
    private static ArrayList<String> reverse(ArrayList<String> a) {
        ArrayList<String> ret = new ArrayList<String>();

        for (int i = a.size() - 1; i >= 0; i--)
            ret.add(a.get(i));

        return ret;
    }

    public static void main(String args[]) {
        parser p = new parser();

        String uInput = p.readExpressionInput();
        String rules = p.readRuleInput();
        String iterations = p.readIterations();
        String simplified = p.simplify(uInput, rules, iterations);
        System.out.println(simplified);
    }

    //Read expression from the user
    public String readExpressionInput() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter expression: ");
        String uInput = input.nextLine();

        return uInput;

    }

    //Read which rules the user wants to apply
    public String readRuleInput() {
        System.out.println("1: a + (b + y) = (a + b) + y\n2: a + b = b + a\n3: a + MTST = a\n4: a + a = a\n5: a(by) = (ab)y\n6: (EPSILON)(a) = (a)(EPSILON) = (a)\n7: a(b + y) = ab + ay\n8: (a + b)y = ay + by\n9: (MTST)(a) = (a)(MTST) = (MTST)\n10: EPSILON + (a)(a)* = (a)*\n11: EPSILON + (a)*(a) = (a)*\n12: b + (a)(y) <_ (y) = (a)*(b) <_ (y)\n13: b + (y)(a) <_ (y) = (b)(a)* <_ (y)");
        System.out.println("Enter rules separated by spaces: ");
        Scanner input = new Scanner(System.in);
        String uInput = input.nextLine();
        return uInput;
    }

    //Read how many iterations the user wants to apply
    public String readIterations() {
        System.out.println("How many iterations: ");
        Scanner input = new Scanner(System.in);
        String uInput = input.nextLine();
        return uInput;
    }

    //Turn a string into array list of tokens
    public ArrayList<String> tokenize(String fullInput) {
        ArrayList<String> tokens = new ArrayList<String>();
        while (!fullInput.isEmpty()) {
            if (fullInput.indexOf(" ") >= 0) {
                tokens.add(fullInput.substring(0, fullInput.indexOf(" ")));
                fullInput = fullInput.substring(fullInput.indexOf(" ") + 1);
            } else {
                tokens.add(fullInput);
                fullInput = "";
            }

        }
        return tokens;

    }

    //Turn array list of tokens into string
    public String detokenize(ArrayList<String> tokens) {
        String ret = "";

        for (String s : tokens) {
            ret += s + " ";
        }
        return ret;
    }

    //Applies rule depending on string of rules
    public String simplify(String input, String rule, String iterations) {
        String ret = "";
        ArrayList<String> tokens = tokenize(input);
        ArrayList<String> rules = tokenize(rule);

        for (int j = 0; j < Integer.parseInt(iterations); j++) {
            for (int i = 0; i < rules.size(); i++) {
                if (Integer.parseInt(rules.get(i)) == 1) {
                    tokens = nineOne(tokens);
                    System.out.println("1: " + tokens);
                } else if (Integer.parseInt(rules.get(i)) == 2) {
                    tokens = nineTwo(tokens);
                    System.out.println("2: " + tokens);
                } else if (Integer.parseInt(rules.get(i)) == 3) {
                    tokens = nineThree(tokens);
                    System.out.println("3: " + tokens);
                } else if (Integer.parseInt(rules.get(i)) == 4) {
                    tokens = nineFour(tokens);
                    System.out.println("4: " + tokens);
                } else if (Integer.parseInt(rules.get(i)) == 5) {
                    tokens = nineFive(tokens);
                    System.out.println("5:" + tokens);
                } else if (Integer.parseInt(rules.get(i)) == 6) {
                    tokens = nineSix(tokens);
                    System.out.println("6: " + tokens);
                } else if (Integer.parseInt(rules.get(i)) == 7) {
                    tokens = nineSeven(tokens);
                    System.out.println("7: " + tokens);
                } else if (Integer.parseInt(rules.get(i)) == 8) {
                    tokens = nineEight(tokens);
                    System.out.println("8: " + tokens);
                } else if (Integer.parseInt(rules.get(i)) == 9) {
                    tokens = nineNine(tokens);
                    System.out.println("9: " + tokens);
                } else if (Integer.parseInt(rules.get(i)) == 10) {
                    tokens = nineTen(tokens);
                    System.out.println("10: " + tokens);
                } else if (Integer.parseInt(rules.get(i)) == 11) {
                    tokens = nineEleven(tokens);
                    System.out.println("11: " + tokens);
                } else if (Integer.parseInt(rules.get(i)) == 12) {
                    tokens = nineTwelve(tokens);
                    System.out.println("12: " + tokens);
                } else if (Integer.parseInt(rules.get(i)) == 13) {
                    tokens = nineThirteen(tokens);
                    System.out.println("13: " + tokens);
                }
            }
            ret = detokenize(tokens);
        }

        return ret;

    }

}