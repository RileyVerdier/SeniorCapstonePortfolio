/*
    Joshua Freeman
    10/31/19
    CSC414 Matrix Tools
 */

import java.text.DecimalFormat;
import java.util.ArrayList;

public class Matrix {

    /*
        Adds two matrix of the same dimensions together.
     */
    public static ArrayList<ArrayList<Object>> add(ArrayList<ArrayList<Object>>m1, ArrayList<ArrayList<Object>>m2) throws Exception {

        if(!sameDimensions(m1,m2))
            throw new Exception("Matrix dimensions do not match.");

        ArrayList<ArrayList<Object>> m3 = new ArrayList<ArrayList<Object>>();
        for(int row = 0; row < m1.size(); row++) {
            ArrayList<Object> currRow = new ArrayList<Object>();
            for (int col = 0; col < m1.get(0).size(); col++) {
                try{
                    currRow.add(Double.valueOf((String)m1.get(row).get(col)) + Double.valueOf((String)m2.get(row).get(col)));
                }catch(Exception e){
                    currRow.add((String)m1.get(row).get(col) + " + " + (String)m2.get(row).get(col));
                }

            }
            m3.add(currRow);
        }
        return m3;
    }

    /*
        Multiplies matrix m1 and matrix m2 together. Also works for matrix of 1x1 size. Matrix must have same number of matrix 1 rows and matrix 2 columns
     */
    public static ArrayList<ArrayList<Object>> multiply(ArrayList<ArrayList<Object>>m1, ArrayList<ArrayList<Object>>m2){

        int aRows = m1.size();
        int aColumns = m1.get(0).size();
        int bRows = m2.size();
        int bColumns = m2.get(0).size();


        if (aColumns != bRows) {
            throw new IllegalArgumentException("A:Rows: " + aColumns + " did not match B:Columns " + bRows + ".");
        }
        if(aRows == bColumns && aColumns != bRows){
            ArrayList<ArrayList<Object>> temp;
            temp = m1;
            m1 = m2;
            m2 = temp;
        }
        ArrayList<ArrayList<Object>> m3 = new ArrayList<ArrayList<Object>>();
        boolean doub = false;
        if((m1.size() != 1 || m1.get(0).size() != 1) && (m2.size() != 1 || m2.get(0).size() != 1)) {

            double currTotal = 0;
            String strTotal = "";
            for (int row1 = 0; row1 < m1.size(); row1++) {

                ArrayList<Object> currRow = new ArrayList<Object>();
                for (int col1 = 0; col1 < m2.get(0).size(); col1++) {

                    for (int col2 = 0; col2 < m1.get(0).size(); col2++) {
                        try{
                            currTotal += Double.valueOf((String)m1.get(row1).get(col2)) * Double.valueOf((String) m2.get(col2).get(col1));
                            doub = true;
                        }catch(Exception e){
                            strTotal += (String)m1.get(row1).get(col2) + " " + (String) m2.get(col2).get(col1) + " ";
                        }
                    }
                    if(doub)
                        currRow.add(currTotal);
                    else {
                        strTotal = strTotal.substring(0, strTotal.length()-1);
                        currRow.add(strTotal);
                    }
                    currTotal = 0;
                    strTotal = "";
                }
                m3.add(currRow);
            }
        }else{ //For a matrix of size 1
            double digit = 0.0;
            String singleVal = "";
            ArrayList<ArrayList<Object>> currArray = new ArrayList<ArrayList<Object>>();
            if((m1.size() == 1 && m1.get(0).size() == 1)) {
                if(doub)
                    digit = (Double) m1.get(0).get(0);
                else
                    singleVal = (String) m1.get(0).get(0);
                currArray = m2;
            }
            else {
                if(doub)
                    digit = (Double) m2.get(0).get(0);
                else
                    singleVal = (String) m2.get(0).get(0);
                currArray = m1;
            }

            for(int row = 0; row < currArray.size();row++){
                ArrayList<Object> currRow = new ArrayList<Object>();
                for(int col = 0; col < currArray.get(0).size();col++){
                    if(doub)
                        currRow.add( digit * (Double)currArray.get(row).get(col));
                    else
                        currRow.add( " " + singleVal + " " +(String)currArray.get(row).get(col) + " ");
                }
                m3.add(currRow);
            }

        }
        return m3;
    }

    /*
        Returns the E* of a matrix. If the matrix is 4x4, calculations are done in current instance of the class.
        If the array is 1 in size the array is returned back.
     */
    public static ArrayList<ArrayList<Object>> star(ArrayList<ArrayList<Object>> m1) throws Exception{
        if(m1.size() != m1.get(0).size())
            throw new Exception("Matrix dimensions do not match.");

        ArrayList<ArrayList<Object>> E = new ArrayList<ArrayList<Object>>();
        int n = m1.size();

        ArrayList<Object> row1 = new ArrayList<Object>();
        ArrayList<Object> row2 = new ArrayList<Object>();
        if(n > 2) {
            ArrayList<ArrayList<Object>> A = copyMatrixPortion(m1, 0, 0, 0, 0);
            ArrayList<ArrayList<Object>> B = copyMatrixPortion(m1, 0, 0, 1, n-1);
            ArrayList<ArrayList<Object>> C = copyMatrixPortion(m1, 1, n-1,0, 0);
            ArrayList<ArrayList<Object>> D = copyMatrixPortion(m1, 1, n-1,1,n-1);


            ArrayList<ArrayList<Object>> aStar = Matrix.star(Matrix.add(A, Matrix.multiply((Matrix.multiply(B, Matrix.star(D))), C)));
            ArrayList<ArrayList<Object>> bStar = Matrix.multiply(Matrix.star(Matrix.add(A, Matrix.multiply((Matrix.multiply(B, Matrix.star(D))), C))), Matrix.multiply(B, Matrix.star(D)));

            ArrayList<ArrayList<Object>> cStar =Matrix.multiply(Matrix.star(Matrix.add(D, Matrix.multiply((Matrix.multiply(C, Matrix.star(A))), B))), Matrix.multiply(C, Matrix.star(A)));
            ArrayList<ArrayList<Object>> dStar=  Matrix.star(Matrix.add(D, Matrix.multiply((Matrix.multiply(C, Matrix.star(A))), B)));

            for(int i = 0; i < n; i++){
                ArrayList<Object> tempRow = new ArrayList<Object>();
                if(i == 0){
                    tempRow.add(aStar.get(0).get(0));
                    for(int j = 0; j < n-1; j++)
                        tempRow.add(bStar.get(0).get(j));
                }else{
                    tempRow.add(cStar.get(i-1).get(0));
                    for(int j = 0; j < n-1; j++)
                        tempRow.add(dStar.get(i-1).get(j));

                }
                E.add(tempRow);
            }


        }else if (n == 2){
            try{
                double A = Double.valueOf((String)m1.get(0).get(0));
                double B = Double.valueOf((String)m1.get(0).get(1));
                double C = Double.valueOf((String)m1.get(1).get(0));
                double D = Double.valueOf((String)m1.get(1).get(1));

                row1.add(A + B * D * C);
                row1.add((A + B * D * C) * B * D);
                E.add(row1);

                row2.add((D + C * A * B) * C * A);
                row2.add(D + C * A * B);
                E.add(row2);
            }catch(Exception e){
                String A = (String)m1.get(0).get(0);
                String B = (String)m1.get(0).get(1);
                String C = (String)m1.get(1).get(0);
                String D = (String)m1.get(1).get(1);

                row1.add(A + " + " + B + " " + D + " " + C);
                row1.add("( " + A + " + " + B + " " + D + " " + C + " ) " + B + " " + D);
                E.add(row1);

                row2.add("( " + D + " + " + C + " " + A + " " + B + " ) " + C + " " + A);
                row2.add(D + " + " + C + " " + A + " " + B);
                E.add(row2);
            }

        }else if (n == 1){
            E = m1;
        }
        return E;
    }

    /*
        Copies matrix using x1y1,x2y2
     */
    private static ArrayList<ArrayList<Object>> copyMatrixPortion(ArrayList<ArrayList<Object>> m1, int row1, int row2, int col1, int col2){
        ArrayList<ArrayList<Object>> copiedMatrix = new ArrayList<ArrayList<Object>>();

        for(int row = row1; row <= row2; row++){
            ArrayList<Object> currRow = new ArrayList<Object>();
            for(int col = col1; col <= col2; col++){
                currRow.add(m1.get(row).get(col));
            }
            copiedMatrix.add(currRow);
        }
        return copiedMatrix;
    }
    /*
        Returns true if the dimensions of the array are the same
     */
    private static boolean sameDimensions(ArrayList<ArrayList<Object>>m1, ArrayList<ArrayList<Object>>m2){
        int m1Row = m1.size();
        int m2Row = m2.size();
        int m1Col = m1.get(0).size();
        int m2Col = m2.get(0).size();

        if(m1Row == m2Row && m1Col == m2Col)
            return true;
        else
            return false;
    }

    /*
        Prints matrix while formatting double to #.00
     */
    public static void print(ArrayList<ArrayList<Object>> m){
        DecimalFormat numberFormat = new DecimalFormat("#.00");
        for(int row = 0; row < m.size(); row++){
            for(int col = 0; col < m.get(0).size(); col++){
                System.out.print(numberFormat.format(m.get(row).get(col) )+ " ");
            }
            System.out.println();
        }
    }

    /*
        Generates random matrix using Math.random, which results in a random double from 0 to 10
     */
    public static ArrayList<ArrayList<Object>> generateMatrix(int nRows, int nCols){
        ArrayList<ArrayList<Object>> ret = new ArrayList<ArrayList<Object>>();

        for(int row = 0; row < nRows; row++){
            ArrayList<Object> currRow = new ArrayList<Object>();
            for(int col = 0; col < nCols; col++){
                currRow.add((Math.random() * 10));
            }
            ret.add(currRow);
        }

        return ret;

    }
    //Convert MAT[[]] to array list matrix
    public static ArrayList<ArrayList<Object>> stringToMatrix(String matrix){
        ArrayList<ArrayList<Object>> ret = new ArrayList<ArrayList<Object>>();
        ArrayList<Object> row = new ArrayList<Object>();
        boolean insideBracket = false;
        if(matrix.contains("MAT")){
            for(int i = 0; i < matrix.length(); i++){
                char c = matrix.charAt(i);
                if(c != ']'){
                    if(c == '[' && insideBracket == false) {
                        insideBracket = true;
                    }else if(insideBracket == true && c != '['){
                        String s = "";
                        int k = i;
                        while(matrix.charAt(k) != ',' && matrix.charAt(k) != ']'){
                            s += matrix.charAt(k);
                            k++;
                        }
                        i = k;
                        row.add(s);
                        if(i+1 != matrix.length() && matrix.charAt(i + 1) == '['){
                            i--;
                        }
                    }
                }else{
                    ret.add(row);
                    row = new ArrayList<Object>();
                    if(matrix.charAt(i) == ']' && i == matrix.length() -1){
                        i = matrix.length();
                    }
                }
            }
        }
        return ret;
    }
    //Convert array list matrix to MAT[[]]
    public static String matrixToString(ArrayList<ArrayList<Object>> matrix){
        String ret = "MAT[";
        for(int row = 0; row < matrix.size(); row++){
            ret += "[";
            for(int col = 0; col < matrix.get(0).size(); col++){
               ret += matrix.get(row).get(col);
               ret += ",";
            }
            ret = ret.substring(0, ret.lastIndexOf(','));
            ret += "]";
        }
        ret += "]";
        return ret;
    }
    /*public static void main(String[] args){

        System.out.println("Starting arrays: \n");
        ArrayList<ArrayList<Object>> testM2 = Matrix.generateMatrix(2,2);
        Matrix.print(testM2);
        System.out.println();
        ArrayList<ArrayList<Object>> testM3 = Matrix.generateMatrix(3,3);
        Matrix.print(testM3);
        System.out.println();
        ArrayList<ArrayList<Object>> testM4 = Matrix.generateMatrix(4,4);
        Matrix.print(testM4);
        System.out.println("____________________");

        try {
            System.out.println("Star properties:\n ");
            ArrayList<ArrayList<Object>> E2 = Matrix.star(testM2);
            Matrix.print(E2);
            System.out.println();
            ArrayList<ArrayList<Object>> E3 = Matrix.star(testM3);
            Matrix.print(E3);
            System.out.println();
            ArrayList<ArrayList<Object>> E4 = Matrix.star(testM4);
            Matrix.print(E4);
            System.out.println();

        }catch(Exception e){
            System.out.println("Exception: " + e);
        }
    }*/

    public static void main(String args[]){
        String matrix1 = "MAT[[a,ab,aab][c,cd,ccd]]";
        String matrix2 = "MAT[[a,b,c,d][e,f,g,h][i,j,k,l]]";
        ArrayList<ArrayList<Object>> matrixArray1 = Matrix.stringToMatrix(matrix1);
        ArrayList<ArrayList<Object>> matrixArray2 = Matrix.stringToMatrix(matrix2);
        String matrix3 = Matrix.matrixToString(matrixArray1);
        String matrix4 = Matrix.matrixToString(matrixArray2);
        System.out.println("1: " + matrix1);
        System.out.println("2: " + matrix2);
        System.out.println("3: " + matrix3);
        System.out.println("4: " + matrix4);
    }

}