import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;

public class FibSphere {

    public double latitude(int i, int n){
        double temp = ((2 * i)/(double)(2 * n + 1));
        if(i <= 0)
            return Math.asin(temp);
        else
            return (Math.PI - Math.asin(temp));
    }
    public double longitude(int i){
        double phi = 1.61803398874989484820;
        return ((2 * Math.PI * i) / phi);
    }

    public ArrayList<Double> generate_x(int n, int r){
        ArrayList<Double> a = new ArrayList<>();
        int i = n * -1;

        while(i <= n){
            a.add((-1 * r) * Math.cos(latitude(i, n)) * Math.cos(longitude(i)));
            i++;
        }
        return a;
    }
    public ArrayList<Double> generate_y(int n, int r){
        ArrayList<Double> a = new ArrayList<>();
        int i = n * -1;

        while(i <= n){
            a.add((r) * Math.sin(latitude(i, n)));
            i++;
        }
        return a;
    }

    public ArrayList<Double> generate_z(int n, int r){
        ArrayList<Double> a = new ArrayList<>();
        int i = n * -1;

        while(i <= n){
            a.add((r) * Math.cos(latitude(i, n)) * Math.sin(longitude(i)));
            i++;
        }
        return a;
    }

    public ArrayList<ArrayList<Double>> generate_coordinates(int n, int r){
        ArrayList<ArrayList<Double>> a = new ArrayList<>();
        ArrayList<Double> x = generate_x(n,r);
        ArrayList<Double> y = generate_y(n,r);
        ArrayList<Double> z = generate_z(n,r);
        int i = 0;

        while(i < x.size()){
            ArrayList<Double> b = new ArrayList<>();
            b.add(x.get(i));
            b.add(y.get(i));
            b.add(z.get(i));
            a.add(b);
            i++;
        }
        return a;
    }

    public static void main(String args[]){
        FibSphere fs = new FibSphere();
        ArrayList<ArrayList<Double>> points = fs.generate_coordinates(20, 1);

        try{
            String str = "# x y z\n";
            for(int i = 0; i < points.size(); i++){
                str += points.get(i).get(0) + " ";
                str += points.get(i).get(1) + " ";
                str += points.get(i).get(2) + "\n";
            }
            BufferedWriter writer = new BufferedWriter(new FileWriter("data2.dat"));
            writer.write(str);

            writer.close();
        }catch(Exception e){
        }
        System.out.println("Wrote data points to file.");
    }
}
